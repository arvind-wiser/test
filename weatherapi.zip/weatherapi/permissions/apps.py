from django.apps import AppConfig


class PermissionsConfig(AppConfig):
    name = 'permissions'
