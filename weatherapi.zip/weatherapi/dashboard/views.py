from django.conf import settings
import requests
from django.http import HttpResponse
from django.http import JsonResponse
from django.shortcuts import render
from django.template.loader import get_template
from django.views.generic import View, TemplateView
from api.accuweather.accuweather import AccuWeather
from permissions.mixins import LoginPermissionCheckMixin
from users.models import Users
from models.dao.weather_search import WeatherSearch
from datetime import datetime

from django.contrib import messages


class Dashboard(LoginPermissionCheckMixin, View):
    
    permission_required = 'dashboard.home'
    template_name = 'dashboard/index.html'

    def get(self, request, *args, **kwargs):
        weather_data = {}
        if request.GET.get("q", "notfound") != "notfound":
            accu = AccuWeather()
            json_data = accu.get_current_weather(request.GET.get("q"))            
            if json_data["cod"] != '404':
                weather_data["search_date"] = datetime.now().strftime("%d %B,%Y")
                weather_data["week_day"] = datetime.now().strftime("%A")
                weather_data["temp"] = json_data["main"]["temp"]
                weather_data["city_name"] = json_data["name"]
                weather_data["country_code"] = json_data["sys"]["country"]
                weather_data["description"] = json_data["weather"][0]["description"]
                WeatherSearch().save_weather(request, json_data)
        return render(request, self.template_name, context={"weather_data":weather_data})




