from django.urls import path
from roles import views

urlpatterns = [
    path('', views.ListRolesView.as_view(), name='list-roles'),
    path('create-role', views.CreateRoleView.as_view(), name='create-role'),
    path('update-role/<int:id>', views.UpdateRoleView.as_view(), name='update-role'),
    path('delete-role/<int:id>', views.DeleteRoleView.as_view(), name='delete-role'),
    path('load-roles', views.LoadRoles.as_view(), name='load-roles'),
    
]
