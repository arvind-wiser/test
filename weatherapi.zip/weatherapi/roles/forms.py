from django.forms import ModelForm, Textarea, Select
from django import forms
from django.forms import ModelChoiceField
from django.contrib.auth.forms import PasswordResetForm
from .models import Roles
from utils import get_status_dict
from django.db.models import Q 
class RoleForm(ModelForm):    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)             
        if self.instance.pk:            
            self.fields['dept'].initial = self.instance.dept
    class Meta:
        model = Roles
        exclude = ('description', 'status', 'created_by', 'updated_by', 'created', 'updated')
class RoleEditForm(ModelForm):
    status =forms.IntegerField(widget=forms.Select(choices=list(get_status_dict().items())))
    class Meta:
        model = Roles
        exclude = ('description', 'created_by', 'updated_by', 'created', 'updated')

class RoleSearchForm(RoleForm):    
    status_choices = list(get_status_dict().items())
    status_choices.insert(0,('','Select Status'))
    status = forms.ChoiceField(choices=status_choices)
    class Meta:
        model = Roles
        exclude = ('password', 'created_by', 'updated_by', 'created', 'updated')
       
    