from .models import Roles
import django_filters

class RoleFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='icontains')     
    class Meta:
        model = Roles
        fields = ['name','status']