from django.shortcuts import render
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.db.models import Q
from .forms import RoleForm, RoleSearchForm, RoleEditForm
from .models import Roles
from django.views.generic import ListView
from .filters import RoleFilter
from django.urls import reverse_lazy, reverse
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.conf import settings
from permissions.mixins import LoginPermissionCheckMixin

class CreateRoleView(LoginPermissionCheckMixin, CreateView):
    permission_required = 'list-roles'
    model = Roles
    form_class = RoleForm
    template_name = 'roles/create_role.html'
    success_url = reverse_lazy('create-role')        
    def form_valid(self, form):
        # This method is called when valid form data has been POSTed. 
        form = form.save(commit=False) 
        form.status = 1      
        form.created_by = self.request.user
        form.updated_by = self.request.user
        new_form = form.save()
        messages.success(self.request, 'Role created successfully.')
        return HttpResponseRedirect(self.success_url)
    
    def form_invalid(self, form):
        #print(form.errors)        
        return CreateView.form_invalid(self, form)
        
    def get_template_names(self):
        # Sometimes the is_ajax() is not working properly so if it doesn't 
        # just pass the ajax_partial query parameter to your ajax request
        if self.request.is_ajax():
            return 'roles/role_form.html'
        return super().get_template_names()
     
class UpdateRoleView(LoginPermissionCheckMixin, UpdateView):
    permission_required = 'roles.update_role'
    model = Roles
    form_class = RoleEditForm
    template_name = 'roles/update_role.html'        
    pk_url_kwarg = 'id'
    def get_success_url(self):
            return reverse_lazy('update-role', kwargs={'id': self.get_object().id})
         
    def form_valid(self, form):
        # This method is called when valid form data has been POSTed. 
        form = form.save(commit=False)        
        form.updated_by = self.request.user
        form.save()
        messages.success(self.request, "Role updated successfully.")
        return super(UpdateRoleView, self).form_valid(form) 
        
    
    def form_invalid(self, form):
        print(form.errors)          
        return CreateView.form_invalid(self, form)
        
    def get_template_names(self):
        # Sometimes the is_ajax() is not working properly so if it doesn't 
        # just pass the ajax_partial query parameter to your ajax request
        if self.request.is_ajax():
            return 'roles/role_form.html'
        return super().get_template_names() 
      
class DeleteRoleView(LoginPermissionCheckMixin, View):
    permission_required = 'roles.delete_role'
    model = Roles
    form_class = RoleForm         
    def get(self, request, id):
        user = get_object_or_404(Roles, pk=id)
        user.status =2
        user.save()
        messages.success(self.request,'Role deleted successfully.')
        return HttpResponseRedirect(reverse_lazy('list-roles'))
        
class ListRolesView(ListView):
    permission_required = 'roles.list_roles'
    model = Roles
    filterset_class = Roles
    template_name = 'roles/list_roles.html'
    context_object_name = 'roles'
    paginate_by = settings.RECORDS_PER_PAGE
    
    def get_template_names(self):
        # Sometimes the is_ajax() is not working properly so if it doesn't 
        # just pass the ajax_partial query parameter to your ajax request
        if self.request.is_ajax():
            return 'roles/grid_roles.html'
        return super().get_template_names()
    def get_queryset(self):
        if 'sort' in self.request.GET:
            order_by = self.request.GET['sort']
        else:
            order_by = '-id'
        if self.request.GET.get('status') != '2':
            qs = self.model.objects.filter(~Q(status = 2) & ~Q(id = 1)).order_by(order_by)
        else:
            qs = self.model.objects.filter(~Q(id = 1)).order_by(order_by)
        filtered_list = RoleFilter(self.request.GET, queryset=qs)
        print(filtered_list.qs.query)
        return filtered_list.qs
    def get_context_data(self, **kwargs):
        context = super(ListRolesView, self).get_context_data(**kwargs)
        context['filter_form'] = RoleSearchForm(self.request.GET)
        return context
       
class LoadRoles(LoginRequiredMixin, View):
    template_name = 'roles/role_dropdown.html'
    def get(self, request, *args, **kwargs):
        dept_id = 0
        if request.GET['dept_id']:
            dept_id = request.GET['dept_id']
        roles = Roles.objects.filter(Q(dept_id=dept_id) &~Q(dept_id=1)).order_by('name')
        context = {'roles':roles}
        return render(request, self.template_name, context)