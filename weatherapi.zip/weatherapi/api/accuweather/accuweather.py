import requests
import traceback
from . api_base import ApiBase
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from braces.views import JSONResponseMixin

class AccuWeather(ApiBase):
    def __init__(self) -> None:
        super().__init__() 


    def get_current_weather(self, q):
        json_data = self.send_request("GET","data/2.5/weather", params={"q":q, "units":"metric"})
        return json_data

    
