from django.urls import path
from api.demand import demand
from api.demand import transaction_api, vendor_mapping_views,fbpublisher_api

urlpatterns = [
    path('oauth',demand.Demand.as_view()),
    path('transaction',transaction_api.TransactionApi.as_view()),
    path('fbpublisher',fbpublisher_api.FlapbucksPublisherApi.as_view()),
    path('mapping', vendor_mapping_views.VendorMappingView.as_view(), name='mapping'),
    path('question-list', vendor_mapping_views.QuestionListView.as_view(), name='question-list'),
    path('answer-list/<int:question_id>/<int:vendor_id>/<int:country_id>/<int:language_id>', vendor_mapping_views.AnswerListView.as_view(), name='answer-list'),
    path('bulk-update-ans-code', vendor_mapping_views.BulkUpdateAnsCodeView.as_view(), name='bulk-update-ans-code'),
]
