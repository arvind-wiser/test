from django.conf import settings
import requests
class ApiBase():
    
    def __init__(self) -> None:
        self.accu_url = settings.ACCU_URL
        self.accu_key = settings.ACCU_KRY

    def send_request(self,method,url,params, **kwargs):
        params["appid"] = self.accu_key
        if(method == 'get' or method == 'GET'):
            return self.get_request(self.accu_url+url,params, **kwargs)
        
    def get_request(self, url , params, **kwargs):
        try:
            resp = requests.get(url, params=params)
            json_data = resp.json()
            return json_data
        except Exception as e:
            print(e)
