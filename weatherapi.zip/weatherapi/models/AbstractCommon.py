from django.db import models
from django.utils import timezone

class AbstractBaseCommon(models.Model):
    created_by = models.ForeignKey('users.Users', models.DO_NOTHING, db_column='created_by', related_name='a_created_by')
    updated_by = models.ForeignKey('users.Users', models.DO_NOTHING, db_column='updated_by', related_name='a_updated_by')
    created = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField(default=timezone.now)
    
    class Meta:
        abstract = True