from models.table.weather_search_table import WeatherSearchTable
class WeatherSearch(WeatherSearchTable):
    def __str__(self):
        return str(self.city_name)

    def save_weather(self,request, json_data):
        data_dict = dict()
        data_dict["user_id"] = int(request.user.id)
        data_dict["city_name"] = json_data["name"]
        data_dict["lat"] = float(json_data["coord"]["lat"])
        data_dict["long"] = float(json_data["coord"]["lon"])
        data_dict["description"] = json_data["weather"][0]["description"]
        data_dict["temp"] = float(json_data["main"]["temp"])
        data_dict["feels_like"] = float(json_data["main"]["feels_like"])
        data_dict["temp_min"] = float(json_data["main"]["temp_min"])
        data_dict["temp_max"] = float(json_data["main"]["temp_max"])
        data_dict["pressure"] = int(json_data["main"]["pressure"])
        data_dict["humidity"] = int(json_data["main"]["humidity"])
        data_dict["wind_speed"] = json_data["wind"]["speed"]
        data_dict["wind_deg"] = json_data["wind"]["deg"]
        data_dict["sys_sunrise"] = json_data["sys"]["sunrise"]
        data_dict["sys_country"] = json_data["sys"]["country"]
        data_dict["sys_sunset"] = json_data["sys"]["sunset"]
        data_dict["weather_timezone"] = json_data["timezone"]
        weather = WeatherSearch(**data_dict)
        weather.save()

    class Meta:
        app_label = "users"
        managed = False
        db_table = 'weather_search'