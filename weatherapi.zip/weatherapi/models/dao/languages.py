from models.table.languages_table import LanguagesTable

class Languages(LanguagesTable):
         
    def __str__(self):
        return self.name
    
    class Meta:
        app_label = "countries"
        managed = False
        db_table = 'languages'
    