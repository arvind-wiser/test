from models.table.roles_table import RolesTable

class Roles(RolesTable):
        
    def __str__(self):
        return self.name
    
    class Meta:
        app_label = "roles"
        managed = False
        db_table = 'roles'
