from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser, _user_has_perm
)
from django.utils import timezone
from django.core.validators import RegexValidator
class WeatherSearchTable(models.Model):
    user = models.ForeignKey('Users', models.DO_NOTHING)
    city_name = models.CharField(max_length=25)
    lat = models.FloatField()
    long = models.FloatField()
    description = models.CharField(max_length=50)
    temp = models.FloatField()
    feels_like = models.FloatField()
    temp_min = models.FloatField()
    temp_max = models.FloatField()
    pressure = models.IntegerField()
    humidity = models.IntegerField()
    wind_speed = models.FloatField()
    wind_deg = models.IntegerField()
    sys_sunrise = models.IntegerField()
    sys_country = models.CharField(max_length=3)
    sys_sunset = models.IntegerField()
    weather_timezone = models.IntegerField()
    created = models.DateTimeField(default=timezone.now)

    class Meta:
        abstract = True