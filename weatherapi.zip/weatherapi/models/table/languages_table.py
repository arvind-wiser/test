from django.db import models
from django.utils import timezone

class LanguagesTable(models.Model):
    name = models.CharField(max_length=100)
    lang_code = models.CharField(max_length=50)
    status = models.PositiveIntegerField()
    created_by = models.ForeignKey('users.Users', models.DO_NOTHING, db_column='created_by', related_name='l_created_by')
    updated_by = models.ForeignKey('users.Users', models.DO_NOTHING, db_column='updated_by', related_name='l_updated_by')
    created = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField(default=timezone.now)

    class Meta:
        abstract = True
