from django.db import models
from django.utils import timezone
from models.AbstractCommon import AbstractBaseCommon

class RolesTable(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=255, blank=True, null=True)
    status = models.IntegerField()
    created_by = models.ForeignKey('users.Users', models.DO_NOTHING, db_column='created_by', related_name='r_created_by')
    updated_by = models.ForeignKey('users.Users', models.DO_NOTHING, db_column='updated_by', related_name='r_updated_by')
    created = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField(default=timezone.now)

    class Meta:
        abstract = True