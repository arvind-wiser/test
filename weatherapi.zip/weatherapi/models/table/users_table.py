from django.db import models
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser, _user_has_perm
)
from django.utils import timezone
from django.core.validators import RegexValidator
class UsersTable(AbstractBaseUser):
    first_name = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(max_length=255, unique=True)
    password = models.CharField(max_length=255)
    last_login = models.DateTimeField(blank=True, null=True)    
    role = models.ForeignKey('roles.Roles', models.DO_NOTHING)
    dob = models.DateField(blank=True, null=True)
    profile_pic = models.ImageField(upload_to='users/', blank=True, null=True)
    contact_number = models.CharField(max_length=100, blank=True, null=True)
    login_ip = models.CharField(max_length=100, blank=True, null=True)
    status = models.SmallIntegerField(default=1, blank=True, null=True)
    created_by = models.IntegerField()
    updated_by = models.IntegerField()
    created = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField(default=timezone.now)
    
    class Meta:
        abstract = True